<?php include('header.php'); ?>

<h1> Instructions </h1>

<p> In the following section, you will hear a word spoken aloud. Click on the word you hear.</p>

<p> Please make sure your sound is turned on. </p>

<a href="part3.php">
<div class="button"> Next >> </div> 
</a>

<?php include('footer.php'); ?>