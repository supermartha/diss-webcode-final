</div>


<div class="dev">
	<a href="part1_instructions.php">@part1</a> | 
	<a href="part2_instructions.php">@part2</a> | 
	<a href="part3_instructions.php">@part3</a> | 
	<a href="part4_instructions.php">@part4</a> | 
	<a href="part5_instructions.php">@part5</a> | 
</div>

</body>
</html>