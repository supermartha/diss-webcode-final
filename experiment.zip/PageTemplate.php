<?php
#lib/PageTemplate.php
class PageTemplate {
    public $PageTitle;
    public $ContentHead;
    public $ContentBody;
}

?>