<!-- To do: Make sure javascript updates audio file each time record is clicked -->

<?php include('header.php') ?>

<h1> Instructions </h1>

<p> In the next section, we will ask you to read some words aloud.</p>

<p> First, let's check that your microphone is working. Click "Start Recording" and say something. (You might need to click "Allow" if your browser asks for permission.)</p>

	<script src="js/audiodisplay.js"></script>
	<script src="js/recorder.js"></script>
	<script src="js/main.js"></script>
	<script>
	function play() {
		document.getElementById("audio1").src = 'results/part2_' + getCookie("ParticipantID") + '_sample.wav'
    	document.getElementById('audio1').play();
	}

	</script>
	<style>
	canvas { 
		display: inline-block; 
		width: 95%;
		height: 100px;
		margin: 0px;
		margin-top: 20px;
	}
	#controls {
		align-items: center;
		height: 20%;
		width: 100%;
	}
	#record.recording { 
		background: red;
		background: -webkit-radial-gradient(center, ellipse cover, #ff0000 0%,lightgrey 75%,lightgrey 100%,#7db9e8 100%); 
		background: -moz-radial-gradient(center, ellipse cover, #ff0000 0%,lightgrey 75%,lightgrey 100%,#7db9e8 100%); 
		background: radial-gradient(center, ellipse cover, #ff0000 0%,lightgrey 75%,lightgrey 100%,#7db9e8 100%); 
	}
	#save { opacity: 0.25;}
	#save[download] { opacity: 1;}

	</style>

<div class="center">
	<div id="controls">
		<a href ="#/" id="record" onclick="toggleRecording(this);"><div class="button" id="record_button">Start Recording</div></a>
		<a href ="#/" id="save"><div class="button" id="play">Play Recording</div></a>
	</div>
	<div id="viz">
		<canvas id="wavedisplay"></canvas>
	</div>
</div>



<p style="margin-top: 70px">Once you've determined that your microphone works, click "Ready" to begin.</p>

<div class="center">
<a href="part2.php">
<div class="button"> Ready >> </div> 
</a>
</div>

<p class="smaller" style="margin-top: 70px"> *** If you can't get recording to work, you can complete an alternate version of the experiment by <a href="part3_instructions.php">clicking here</a>.</p>
</a>


<?php include('footer.php') ?>