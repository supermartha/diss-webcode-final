<?php include('header.php'); ?>


<?php
// define variables and set to empty values
$name = $email = $gender = $comment = $website = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = test_input2($_POST["name"]);
  $email = test_input2($_POST["email"]);
  $website = test_input2($_POST["website"]);
  $comment = test_input2($_POST["comment"]);
  $gender = test_input2($_POST["gender"]);

  $myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
  $txt = "Cucumber\n";
  fwrite($myfile, $txt);
  $txt = "Jane Doe\n";
  fwrite($myfile, $txt);
  fclose($myfile);

}

?>


<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="demographics">  

<p class="question"> Where did you grow up? </p>
City: <input type="text" name="city1" /> <br />
State/Province: <input type="text" name="state1"> <br />
Country (if not US): <input type="text" name="state1"><br />

<p class="question"> What language(s) could you speak by the time you were 5 years old? </p>
<input type="textbox" name="lg1" />

<p class="question"> Gender: </p>
<input type="radio" name="gender" /> female <input type="radio" name="gender" /> male <input type="radio" name="gender" /> other: <input type="text" name="gender_text">

<p class="question"> Race/Ethnicity: </p>
<input type="checkbox" name="race" /> white <br />
<input type="checkbox" name="race" /> black / African-American <br />
<input type="checkbox" name="race" /> Hispanic / Latino/a <br />
<input type="checkbox" name="race" /> Asian <br />
<input type="checkbox" name="race" /> American Indian or Alaska Native <br />
<input type="checkbox" name="race" /> Native Hawaiian or other Pacific Islander <br />
<input type="checkbox" name="race" /> other: <input type="text" name="race_text">

<p class="question"> What year were you born? <input type="textbox" name="lg1" /></p> 

<p class="question"> What is your current occupation? <input type="textbox" name="lg1" /></p>

<p class="question"> Highest degree obtained: <input type="textbox" name="lg1" /></p>

<p class="question"> Zip code: <input type="textbox" name="lg1" /></p>

<p class="question"> What did you think this experiment was about? <input type="textbox" name="lg1" /></p>

<p class="question"> Any comments for the researchers? <input type="textbox" name="lg1" /></p>




<a href="finish.php">
<div class="button"> Finish </div> 
</a>

<?php include('footer.php') ?>