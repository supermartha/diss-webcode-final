<?php include('header.php'); ?>

<h1>Instructions </h1>

<p> Finally, let's ask a few questions about yourself. </p>

<a href="part5.php">
<div class="button"> Ready </div> 
</a>

<?php include('footer.php') ?>