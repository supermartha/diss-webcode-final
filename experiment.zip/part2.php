<?php include('header.php') ?>

	<script src="js/audiodisplay.js"></script>
	<script src="js/recorder2.js"></script>
	<script src="js/main2.js"></script>
	<script>
	function play() {
    	document.getElementById('audio1').play();
	}
	</script>
	<style>
	canvas { 
		display: inline-block; 
		width: 95%;
		height: 0px;
		margin: 0px;
	}
	#controls {
		align-items: center;
		height: 20%;
		width: 100%;
	}


	</style>

<script>
	var words = ['pen','pin','meant','mint','Ben','bin','ten','tin','cents','since','Jen','gin','Ken','kin',
			'cat','bat','dog','talking','task','water','monster','pal','robin','cow','frog','fog','had','carrot',
			'bet','bit','pet','pit','set','sit','dead','did','bed','bid','head','hid','Keds','kit','ham'];
	window.onload = function() {
		document.getElementById('total').innerHTML = words.length - 1;
		document.getElementById('progressbar').max = words.length - 1;
	}
	var count = -1
	function shuffleArray(array) {
    	for (var i = array.length - 1; i > 0; i--) {
        	var j = Math.floor(Math.random() * (i + 1));
        	var temp = array[i];
        	array[i] = array[j];
        	array[j] = temp;
    	}
	}
	shuffleArray(words);
	words.push(''); // empty string so nothing displays after final click

	function changeText(e) {
		if (document.getElementById("pause_button").innerHTML == 'Resume Recording') {
			window.alert('Please resume recording to continue.');
		}
	    else if (e.classList.contains("recording")) {
			audioRecorder.stop();
			e.classList.remove("recording");
			audioRecorder.getBuffers( gotBuffers ); 
			document.getElementById('boldStuff').innerHTML = '<span class="invisible">()</span>';
			document.getElementById('saving_text').innerHTML = 'Saving audio . . . click on "Next Word" again to advance to the next word';
			}
	    else{
			count = count + 1;
			if (count == words.length - 1) {location.href="part3_instructions.php"};
			document.getElementById('boldStuff').innerHTML = words[count]; 
			document.getElementById('saving_text').innerHTML = '';
			document.getElementById('progressbar').value = count + 1;
			document.getElementById('completed_count').innerHTML = count + 1;

			if (!audioRecorder)
	    		return;
			e.classList.add("recording");
			audioRecorder.clear();
			audioRecorder.record();
			document.getElementById("record_button").style.background = '#009900';
			document.getElementById("record_button").innerHTML = 'Next Word'; 
    		}
    	}

	function pauseButton(e) {
	    if (e.classList.contains("paused")) {
			if (!audioRecorder)
	    		return;
			e.classList.remove("paused");
			audioRecorder.clear();
			audioRecorder.record();
			document.getElementById("pause_button").style.background = '#009900'
			document.getElementById("pause_button").innerHTML = 'Pause Recording'
			document.getElementById("record_button").style.opacity = 1
			document.getElementById("record").style.opacity = 1
			document.getElementById('saving_text').innerHTML = '';
		}

		else {
			audioRecorder.stop();
			e.classList.add("paused");
			document.getElementById("pause_button").style.background = '#ff3300'
			document.getElementById("pause_button").innerHTML = 'Resume Recording'
			document.getElementById("record_button").style.opacity = .5
			document.getElementById("record").style.opacity = .5
			document.getElementById('saving_text').innerHTML = '';
		}

		// toggleRecording(e);
	}

</script>

<p class="wordlist"> <b id='boldStuff'> Click to begin </b> </script> </p>


<div class="center">
	<div id="controls">
		<a href ="#/" id="record" onclick="changeText(this);"><div class="button" id="record_button">Start Recording</div></a>
		<a href ="#/" id="pause" onclick="pauseButton(this);"><div class="button" id="pause_button">Pause Recording</div></a>
		<br />
	</div>
	<p class="smaller" id="saving_text"> </p>
	<div id="viz">
		<canvas id="analyser" ></canvas>
		<canvas id="wavedisplay"></canvas>
	</div>


<br /><br />
<progress max="44" value="1" id="progressbar"></progress>  <span class="progress_count"> <span id="completed_count">0</span> / <span id="total">?</span> </span>
<br /><br />

</div>

<?php include('footer.php') ?>
