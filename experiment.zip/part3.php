<?php include('audio_header.php'); ?>

<script>
	var words = [['pen','pin'],['ten','tin'],['meant','mint'],['bet','bit'],['cat','bat']];
	var audio = ['pen.wav','pin.wav','ten.wav','tin.wav','meant.wav','mint.wav','bet.wav','bit.wav','cat.wav','bat.wav'];

	// x3
	words = words.concat(words, words, words);
	audio = audio.concat(audio, audio, audio);

	/* Match audio files to words */
	var sounds = []; // an array of 'sound' objects
	for (i = 0; i < audio.length; i++) {
		sounds.push({soundfile: audio[i], pair: words[Math.floor(i/2.0)]});
	}

	var count = -1;
	shuffleArray(sounds);
	// words.push(['','']); // empty string so nothing displays after final click

	function changeText() {
		count = count + 1;
		if (count == sounds.length - 1) {
			$.ajax({
				url: 'save_data.php',
				data: {results : results},
				type: 'POST' });
			location.href="part4_instructions.php"
			}
		document.getElementById('word1').innerHTML = sounds[count].pair[0];
		document.getElementById('word2').innerHTML = sounds[count].pair[1];
		document.getElementById('audio1').src = "part3_stimuli/" + sounds[count].soundfile;
		document.getElementById('audio1').play();
	}

	var results = [3];
	initial = ['example','banana'];

	// Will also need to record which stimuli were played
	function record1() {
		if (count == -1) {results.push([initial, 'example.wav', initial[0]].join(':'))}
		else {results.push([sounds[count].pair, sounds[count].soundfile, sounds[count].pair[0]].join(':'))};
		changeText()
	}

	function record2() {
		if (count == -1) {results.push([initial, 'example.wav', initial[1]].join(':'))}
		else {results.push([sounds[count].pair, sounds[count].soundfile, sounds[count].pair[1]].join(':'))};
		changeText()
	}

</script>



<p class="wordlist"> <a href="#" class="wordlist" id="word1" onclick="record1()">example</a> / <a href="#" class="wordlist" id="word2" onclick="record2()">banana</a> </p>



<?php include('footer.php'); ?>