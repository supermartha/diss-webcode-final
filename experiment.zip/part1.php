<?php include('audio_header.php'); ?>

<?php
// Get list of files from directory
if ($handle = opendir('daniel_stimuli/')) {
	$audio_list = array();
    while (false !== ($entry = readdir($handle))) {
        if ($entry != "." && $entry != "..") {
            $audio_list[] = $entry;
        }
    }
    closedir($handle);
}

?>

<script>
	var audio = <?php echo json_encode($audio_list); ?>;

	var count = 0;
	shuffleArray(audio);
	// words.push(['','']); // empty string so nothing displays after final click

	// Play first sound on page load
	document.getElementById('audio1').src = "daniel_stimuli/" + audio[count];
	document.getElementById('audio1').play();

	function changeText() {
		count = count + 1;
		if (count == 30) {
			$.ajax({
				url: 'save_data.php',
				data: {results : results},
				type: 'POST' });
			location.href="part2_instructions.php"
			}
		document.getElementById('progressbar').value = count + 1;
		document.getElementById('completed_count').innerHTML = count + 1;
		document.getElementById('educated').value = 500;
		document.getElementById('pretentious').value = 500;
		document.getElementById('class').value = 500;
		document.getElementById('friendly').value = 500;
		document.getElementById('black').value = 500;
		document.getElementById('southern').value = 500;
		document.getElementById('audio1').src = "daniel_stimuli/" + audio[count];
		document.getElementById('audio1').play();
	}

	var results = [1];

	// Will also need to record which stimuli were played
	function record_responses() {
		responses = [audio[count],
			document.getElementById('educated').value, 
			document.getElementById('pretentious').value,
			document.getElementById('class').value,
			document.getElementById('friendly').value,
			document.getElementById('black').value,
			document.getElementById('southern').value];
		results.push(responses.join(':'));
		changeText();
	}

</script>



<form>

<div class="question">
	<p> How <b>educated</b> does this person sound? </p>
	<div class="slider"> not very educated <input type='range' min=0 max=1000 id="educated" /> very educated </div>
</div>

<div class="question">
	<p> How <b>pretentious</b> does this person sound? </p>
	<div class="slider"> not very pretentious <input type='range' min=0 max=1000 id="pretentious" /> very pretentious </div>
</div>

<div class="question">
	<p> How <b>upper class</b> does this person sound? </p>
	<div class="slider"> working class <input type='range' min=0 max=1000 id="class" /> upper class </div>
</div>

<div class="question">
	<p> How <b>friendly</b> does this person sound? </p>
	<div class="slider"> not very friendly <input type='range' min=0 max=1000 id="friendly" /> very friendly </div>
</div>

<div class="question">
	<p> How <b>black</b> does this person sound? </p>
	<div class="slider"> definitely not black <input type='range' min=0 max=1000 id="black" /> definitely black </div>
</div>

<div class="question">
	<p> How <b>Southern</b> does this person sound? </p>
	<div class="slider"> definitely not Southern <input type='range' min=0 max=1000 id="southern" /> definitely Southern </div>
</div>

<a href="#">
<div class="button" onclick="record_responses()"> Next </div> 
</a>

</form>

<br /><br />
<progress max="30" value="1" id="progressbar"></progress>  <span class="progress_count"> <span id="completed_count">1</span> / 30 </span>
<br /><br />

<?php include('footer.php'); ?>
