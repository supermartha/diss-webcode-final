<?php include('header.php'); ?>

<h1>Instructions </h1>

<p> In the next section, we'll ask you whether two words rhyme. Click "yes" or "no" to select your response. </p>

<a href="part4.php">
<div class="button"> Ready </div> 
</a>

<?php include('footer.php'); ?>