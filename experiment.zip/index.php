<html>

<header>
	<title> hello </title>
	<link rel="stylesheet" type="text/css" href="style.css">
</header>

<body>

<div id="main">

<?php include 'part1_instructions.php' ; ?>

</div>



</body>

</html>