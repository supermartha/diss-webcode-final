<?php
// Set cookie for participant ID
$rand = uniqid($more_entropy=TRUE) . $_SERVER['REMOTE_ADDR'];;
setcookie("ParticipantID", $rand);
?>

<?php include('header.php') ?>

<h1> Part 1 </h1>

<p> In this section of the experiment, you will hear different people reading sentences. You will be asked to answer some questions about these people based on the way that they talk. </p>

<p>Please make sure that your sound is turned on.</p>

<a href="part1.php">
<div class="button"> Next >></div> 
</a>

<?php include('footer.php') ?>
