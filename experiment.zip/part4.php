<?php include('header.php'); ?>

<script>
	var words = [['dog','frog'],['pen','sin'],['cat','bat']]
	//,['hen','gin'],['cat','kit'],['scent','meant'],['grin','spin'],['Harry','scary'],['them','him'],['weigh','pay'],['gem','Kim'],['dog','dock'],['might','met'],['cow','tow']];
	var count = -1;
	shuffleArray(words);
	words.push(['','']); // empty string so nothing displays after final click

	function changeText() {
		count = count + 1;
		if (count == words.length - 1) {
			$.ajax({
				url: 'save_data.php',
				data: {results : results},
				type: 'POST',
			});
			location.href="part5_instructions.php"
			}
		document.getElementById('word1').innerHTML = words[count][0];
		document.getElementById('word2').innerHTML = words[count][1];
	}

	var results = [4];

	initial = ['hey','day']

	function record1() {
		if (count == -1) {results.push(initial + ':yes')}
		else {results.push(words[count] + ':yes')};
		changeText()
	}

	function record2() {
		if (count == -1) {results.push(initial + ':no')}
		else {results.push(words[count] + ':no')};
		changeText()
	}

</script>

<p class="rhyme"> Do <b id="word1">hey</b> and <b id="word2">day</b> rhyme?</p>

<p class="wordlist"> <a href="#" class="wordlist" onclick="record1()">yes</a> / <a href="#" class="wordlist" onclick="record2()">no</a> </p>


<?php include('footer.php'); ?>
