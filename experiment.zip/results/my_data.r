setwd('Documents/pin-pen/webpage/results/')

dat <- read.delim('part1_15772b1f4a4d1b127.0.0.1')
head(dat)

dat$guise <- factor(substr(dat$stimulus, 4,11))
head(dat)
dat <- dat[dat$guise %in% c('southern','northern'),]

dat$x <- gsub('.wav','',dat$stimulus)

dat$x = 1

southern <- dat[dat$guise == 'southern',]
northern <- dat[dat$guise == 'northern',]

plot(dat$class ~ dat$x, col=c('red','blue')[dat$guise], pch=19)
legend("right", c('northern','southern'), col=c('red','blue'), pch=19)

plot(educated ~ stimulus, data=dat)

dat$correct <- dat$response

